require([
    'splunkjs/mvc/tableview',
    'splunkjs/mvc/searchmanager',
    'splunkjs/mvc',
    'underscore',
    'splunkjs/mvc/simplexml/ready!'],function(
    TableView,
    SearchManager,
    mvc,
    _
    ){

    var EventSearchBasedRowExpansionRenderer = TableView.BaseRowExpansionRenderer.extend({
        initialize: function(args) {
            
            this._alertsTableView = new TableView({
                managerid: 'alerts_search_manager',
                id: 'alerts_table',
                pageSize: 20
            });

        },

        canRender: function(rowData) {
            return true;
        },

        render: function($container, rowData) {

            var alertSearch = mvc.Components.getInstance("alerts_search_manager");
            var incidentIdCell = _(rowData.cells).find(function (cell) {
               return cell.field === 'incidentId';
            });

            mvc.Components.get("default").set("incidentId", incidentIdCell.value);
            mvc.Components.get("submitted").set("incidentId", incidentIdCell.value);

            $container.append(this._alertsTableView.render().el);
            
        }
    });

    var incidentTable = mvc.Components.getInstance("incident_table");
    incidentTable.getVisualization(function(tableView) {
        tableView.addRowExpansionRenderer(new EventSearchBasedRowExpansionRenderer());
    });
    
});